Original Authors
----------------

 * [Russell Toris](http://users.wpi.edu/~rctoris/) (rctoris@wpi.edu)
 * Jihoon Lee (jihoonlee.in@gmail.com)
 * Brandon Alexander (balexander@willowgarage.com)
 * David Gossow (dgossow@willowgarage.com)
 * Benjamin Pitzer (ben.pitzer@gmail.com)

Contributors
------------

 * [Matthijs van der Burgh](https://github.com/MatthijsBurgh) (MatthijsBurgh@outlook.com)
 * Graeme Yeates (yeatesgraeme@gmail.com)
