exports.DOMImplementation = window.DOMImplementation;
exports.XMLSerializer = window.XMLSerializer;
exports.DOMParser = window.DOMParser;
